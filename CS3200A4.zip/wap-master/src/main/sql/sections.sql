create table sections (
    section_id integer not null auto_increment,
    section_name varchar(255),
    primary key (section_id)
) engine=InnoDB
