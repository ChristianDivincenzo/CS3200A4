class HelloWorld extends React.Component {
  render() {
    return (<p>Hello World!</p>);
  }
}
